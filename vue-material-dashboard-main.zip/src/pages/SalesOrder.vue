<template>
 <div style="margin-left: 30px;">
    <h1 class="md-title">New Sales Order</h1>
    <form novalidate class="md-layout">
      <md-card class="md-layout-item md-size-50 md-small-size-100">
      <md-card-content>
          <!-- <div class="md-layout md-gutter"> -->
            <div class="md-layout-item md-small-size-100">
              <md-field>
                <label for="first-name">Customer Name</label>
                <md-input name="first-name" id="first-name" autocomplete="given-name" />
                <span class="md-error">The first name is required</span>
                <span class="md-error">Invalid first name</span>
              </md-field>
            </div>

            <div class="md-layout-item md-small-size-100">
              <md-field>
                <label for="last-name">Sales Order Date</label>
                <md-input name="last-name" id="last-name" autocomplete="family-name" />
                <span class="md-error">The last name is required</span>
                <span class="md-error">Invalid last name</span>
              </md-field>
            </div>
          <!-- </div> -->

          <!-- <div class="md-layout md-gutter"> -->
            <div class="md-layout-item md-small-size-100">
              <md-field>
                <label for="last-name">Shipment Date</label>
                <md-input name="last-name" id="last-name" autocomplete="family-name" />
                <span class="md-error">The last name is required</span>
                <span class="md-error">Invalid last name</span>
              </md-field>
            </div>

            <div class="md-layout-item md-small-size-100">
              <md-field>
                <label for="age">Customer Phone</label>
                <md-input  id="age" name="age" autocomplete="age" />
                <span class="md-error">The age is required</span>
                <span class="md-error">Invalid age</span>
              </md-field>
            </div>
          <!-- </div> -->

        </md-card-content>

        <!-- <md-progress-bar md-mode="indeterminate" /> -->
        <table class="table">
          <tr>
            <th>Item Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Total</th>
          </tr>
          <ItemTable v-for="item in items" v-bind:key="item" :ItemId="Number(item)"></ItemTable>
        </table>
        
        <md-card-actions>
          <md-button  class="md-primary">Create Order</md-button>
        </md-card-actions>
      </md-card>

      <md-snackbar>The user  was saved with success!</md-snackbar>
    </form>
 </div>
</template>
<script>
import ItemTable from './ItemTable.vue';
export default {

  components: {
        ItemTable  
  },
    data() {
         return {
             items: this.$route.query.salesitems.split(" ")
         };
        },

}
</script>


<template>
 
    <!-- <b-table striped hover :items="items"></b-table> -->

    <tr>
        <td>{{ item.name }}</td>
        <td><md-field>
        <md-input name="first-name" id="first-name" autocomplete="given-name" v-model="saleinputs.quantity" />
        <input type="hidden" v-model="saleinputs.hiddenValue" @input="setAmmount(inputValue)"/>
        </md-field><span><i>In Stock <b>{{ item.quantity }}</b></i></span></td>
        <td>{{ item.price }}</td>
        <td>{{ saleinputs.hiddenValue }}</td>
        <td>{{ item.price * saleinputs.quantity }}</td>
    </tr>
 
</template>

<script>
import axios from 'axios';
export default {
    props: {
        ItemId: Number
    },
    data() {
      return {
         saleinputs: {
            quantity: 1,
            hiddenValue: this.item
         }
      }
    },
    created() {

       console.log(this.saleinputs.hiddenValue);
      //alert(item.price);
       //this.loadItemdata();
       //console.log(item);
    },
    computed: {
        item() {
          return this.$store.state.items.find(item => item.id === this.ItemId)
       }
    },
    methods: {
        loadItemdata() {
        axios
        .get("http://localhost:8000/api/item/details", {
          params: {
            itemID: this.ItemId,
          },
        })
        .then(
          function (response) {
           // this.blocks = response.data;
           console.log(response);
          this.items[0].ItemDetails = response.data.name;
          this.items[0].quantity = 1;
          this.items[0].Price = response.data.price;
          this.items[0].Discount = 0;
          this.items[0].Total = 0;
          }.bind(this)
        );
     }
    }
  }
</script>

<style>
 .md-card .table {
    width: 100%;
 }
 tr {
    text-align: center;
 }
 tr td {
  padding: 15px;
 }
</style>